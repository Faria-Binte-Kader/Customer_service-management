/*#include <iostream>
#include <string>

#include <customer.h>
#include <employee.h>
#include <company.h>

#define MAX_EMPLOYEE 100
#define MAX_CUSTOMER 20

using namespace std;

int main()
{
    Customer c("Mr.x");
    Employee e("Arobi");
    Company cm("Koyra UHC");
    cm.addEmployee(e);
    cm.addEmployee(Employee("Tuli"));
    cm.add(c,0);
    cm.add(Customer("Mr. Y"),0);
    cm.add(Customer("Mr. Z"),0);
    cm.add(Customer("Mr. C"),1);
    cm.add(Customer("Mrs. C"),1);
    cm.served(3);
    cm.showStatus();
}
*/

/*#include<bits/stdc++.h>
#include "student.h"
#include "customer.h"
#include "employee.h"
using namespace std;

int main()
{
    Student st1("ABC","019XXXXXXXX","Dhaka","abc@gmail.com","Data Science",30000,Date(1,1,2020),180,"A");
    Student st2("XYZ","017XXXXXXXX","Khulna","xyz@gmail.com","Embedded Systems",50000,Date(1,7,2020),90,"B");
    st1.displayinfo();
    st2.displayinfo();

    Customer c1("C1","019XXXXXXXX","Dhaka","c1@gmail.com",70000,120,"User Friendly",Date(5,3,2020),WorkType::Cloud_Computing);
    c1.displayinfo();

    Employee em1("E1","019XXXXXXXX","Dhaka","e1@gmail.com",Designation::Application_Development,10,75000,2);
    em1.displayinfo();
}*/


#include"Customer.h"
#include<ctime>
#include<bits/stdc++.h>
using namespace std;
void receiveInfo(Customer &c)
{
    string nam,phn,addr,em,desc;
    double b;
    int t,wk;
    WorkType w;
    cout<<"Enter your name: ";
    getline(cin,nam);
    cout<<endl;
    cout<<"Enter your contact no.: ";
    getline(cin,phn);
    cout<<endl;
    cout<<"Enter your address: ";
    getline(cin,addr);
    cout<<endl;
    cout<<"Enter your email: ";
    cin>>em;
    cout<<endl;
    cout<<"Enter your budget: ";
    cin>>b;
    cout<<endl;
    cout<<"Enter the time(in months 1-24): ";
    cin>>t;
    cout<<endl;
    cout<<"Enter the type(0.Web_Development\n1.Mobile_Development\n2.Data_Science\n3.Application_Development\n4.Embedded_Systems\n5.Cloud_Computing): ";
    cin>>wk;
    w=static_cast<WorkType>(wk);
    cout<<endl;
    cout<<"Enter description: ";
    getline(cin,desc);
    cout<<endl;
    Date dt2;
    time_t now=time(0);
    tm* dt1=localtime(&now);
    dt2.day=dt1->tm_mday;
    dt2.month=dt1->tm_mon;
    dt2.year=dt1->tm_year;
//    c1.SetName(nam);
//    c1.SetPhone_no(phn);
//    c1.SetAddress(addr);
//    c1.SetEmail(em);
//    c1.setBudget(b);
//    c1.setDuration(t);
//    c1.setDescription(desc);
//    c1.setDate(dt2);
//    c1.setWork(w);
    //cout<<nam<<endl;
    c.setInfo(nam,phn,addr,em,b,t,desc,dt2,w);
}
int main()
{
    //Customer c1("C1","019XXXXXXXX","Dhaka","c1@gmail.com",70000,120,"User Friendly",Date(5,3,2020),WorkType::Cloud_Computing);
    //c1.displayinfo();
    Customer c1;
    receiveInfo(c1);
    c1.displayinfo();
    return 0;
}
